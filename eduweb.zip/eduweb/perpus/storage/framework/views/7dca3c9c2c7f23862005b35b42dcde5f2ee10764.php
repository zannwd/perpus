<!--awal BANNER-->
<div class="col-md-12">
    <img src="<?php echo e(asset('gambar')); ?>/banner.jpg" width="100%" height="280px">
</div>
<!--akhir BANNER--><?php /**PATH C:\eduweb\perpus\resources\views/banner.blade.php ENDPATH**/ ?>